var express = require("express");
var app = express();
var data = require("./database.json");
app.get("/staff", (req, res) => {
  if (!data) {
    res.status(404).send("Could not find information");
  }
  res.send(data);
});
/////////////////////////////
app.get("/staff/:id", (req, res) => {
  const findWorker = data.staff.find((employee) => {
    return parseInt(req.params.id) === employee.id;
  });
  if (!findWorker) {
    res.status(404).send("Could not find employee");
  }
  res.send(findWorker);
});
////////////////////////////////////
const port = process.env.PORT || 4000;
app.listen(4000);